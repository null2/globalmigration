package PC_Inherits;
use base qw(PC_Inherited);

=head1 NAME

PC_Inherit - inherits and doesn't document parent things!

=cut

# documented in parent; stupid to document here, too!
sub new { }

1;
