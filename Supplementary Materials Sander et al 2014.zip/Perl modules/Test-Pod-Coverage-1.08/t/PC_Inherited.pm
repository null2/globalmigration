package PC_Inherited;

=head1 NAME

PC_Inherited - we write docs so you don't have to!

=head2 C< new >

 ...

=cut

sub new { }

1;
